public class Main {
    public static void main(String[] args) {
        System.out.println("Online Course Tracker Running...");
    }
}
