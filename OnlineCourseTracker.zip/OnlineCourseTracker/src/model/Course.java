package model;

public class Course {

    private int id;
    private String name;
    private String platform;
    private int progress;

    public Course() {}

    public Course(String name, String platform, int progress) {
        this.name = name;
        this.platform = platform;
        this.progress = progress;
    }

    public Course(int id, String name, String platform, int progress) {
        this.id = id;
        this.name = name;
        this.platform = platform;
        this.progress = progress;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getPlatform() { return platform; }
    public void setPlatform(String platform) { this.platform = platform; }

    public int getProgress() { return progress; }
    public void setProgress(int progress) { this.progress = progress; }
}
