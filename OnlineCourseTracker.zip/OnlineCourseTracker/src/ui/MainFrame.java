package ui;

import javax.swing.*;
import java.awt.*;

public class MainFrame extends JFrame {

    public MainFrame() {

        setTitle("Online Course Tracker");
        setSize(600, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Colors
        Color teal = new Color(0, 128, 128);
        Color lightTeal = new Color(0, 150, 150);

        // Main panel
        JPanel panel = new JPanel();
        panel.setBackground(teal);
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 50, 20, 50)); // padding

        // Title
        JLabel title = new JLabel("Online Course Tracker", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 24));
        title.setForeground(Color.WHITE);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Buttons - medium size
        JButton btnStudents = new JButton("Students");
        JButton btnCourses = new JButton("Courses");
        JButton btnProgress = new JButton("Progress");

        JButton[] btns = {btnStudents, btnCourses, btnProgress};

        for (JButton b : btns) {
            b.setBackground(lightTeal);
            b.setForeground(Color.WHITE);
            b.setFont(new Font("Arial", Font.BOLD, 18));
            b.setPreferredSize(new Dimension(200, 50));  // medium size
            b.setMaximumSize(new Dimension(300, 50));     // don't grow full width
            b.setAlignmentX(Component.CENTER_ALIGNMENT);
        }

        // Add components with spacing
        panel.add(title);
        panel.add(Box.createVerticalStrut(30));  

        panel.add(btnStudents);
        panel.add(Box.createVerticalStrut(20));  

        panel.add(btnCourses);
        panel.add(Box.createVerticalStrut(20));  

        panel.add(btnProgress);

        add(panel);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainFrame().setVisible(true));
    }
}
