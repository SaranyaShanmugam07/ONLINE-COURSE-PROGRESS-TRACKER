package ui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

import dao.CourseDAO;
import model.Course;

public class CoursePanel extends JFrame {
    private DefaultTableModel tableModel;
    private JTable table;

    public CoursePanel() {
        setTitle("Course Management");
        setSize(700, 450);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        Color teal = new Color(0, 128, 128);
        Color lightTeal = new Color(0, 150, 150);

        // Top title
        JLabel title = new JLabel("Courses", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 22));
        title.setForeground(Color.WHITE);

        // Table
        String[] cols = {"ID", "Course Name", "Platform/Instructor", "Progress"};
        tableModel = new DefaultTableModel(cols, 0) {
            // make cells non-editable directly
            @Override public boolean isCellEditable(int row, int column) { return false; }
        };
        table = new JTable(tableModel);
        table.setRowHeight(28);

        // Buttons
        JButton btnAdd = new JButton("Add");
        JButton btnUpdate = new JButton("Update Progress");
        JButton btnDelete = new JButton("Delete");
        JButton btnRefresh = new JButton("Refresh");

        JButton[] btns = {btnAdd, btnUpdate, btnDelete, btnRefresh};
        for (JButton b : btns) {
            b.setBackground(lightTeal);
            b.setForeground(Color.WHITE);
            b.setFont(new Font("Arial", Font.BOLD, 14));
        }

        // Layout
        JPanel top = new JPanel(new BorderLayout());
        top.setBackground(teal);
        top.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        top.add(title, BorderLayout.CENTER);

        JPanel center = new JPanel(new BorderLayout());
        center.setBackground(teal);
        center.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        center.add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        actions.setBackground(teal);
        actions.add(btnAdd);
        actions.add(btnUpdate);
        actions.add(btnDelete);
        actions.add(btnRefresh);

        JPanel content = new JPanel(new BorderLayout());
        content.setBackground(teal);
        content.add(top, BorderLayout.NORTH);
        content.add(center, BorderLayout.CENTER);
        content.add(actions, BorderLayout.SOUTH);

        add(content);

        // Load data initially
        loadCourses();

        // Button actions
        btnRefresh.addActionListener(e -> loadCourses());

        btnAdd.addActionListener(e -> {
            // simple input dialogs
            String name = JOptionPane.showInputDialog(this, "Course name:");
            if (name == null || name.trim().isEmpty()) return;
            String platform = JOptionPane.showInputDialog(this, "Platform / Instructor:");
            if (platform == null) platform = "";

            String progStr = JOptionPane.showInputDialog(this, "Initial progress (0-100):", "0");
            int prog = 0;
            try { prog = Integer.parseInt(progStr); } catch (Exception ex) { prog = 0; }

            try {
                CourseDAO dao = new CourseDAO();
                // adapt to your Course constructor: (courseName, platform, progress) OR (courseName, instructor)
                Course c = new Course(name, platform, prog);
                boolean ok = dao.addCourse(c);
                if (ok) {
                    JOptionPane.showMessageDialog(this, "Course added");
                    loadCourses();
                } else JOptionPane.showMessageDialog(this, "Add failed");
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            }
        });

        btnUpdate.addActionListener(e -> {
            int r = table.getSelectedRow();
            if (r < 0) { JOptionPane.showMessageDialog(this, "Select a course row first"); return; }
            int id = Integer.parseInt(tableModel.getValueAt(r, 0).toString());
            String progStr = JOptionPane.showInputDialog(this, "New progress (0-100):");
            if (progStr == null) return;
            int prog;
            try { prog = Integer.parseInt(progStr); } catch (Exception ex) { JOptionPane.showMessageDialog(this, "Invalid number"); return; }

            try {
                CourseDAO dao = new CourseDAO();
                // some DAOs provide updateProgress(id, prog) or updateCourse(Course)
                // Try updateProgress first (if exists), otherwise create Course and call updateCourse
                boolean ok = false;
                try {
                    ok = dao.updateProgress(id, prog); // if method exists
                } catch (NoSuchMethodError | AbstractMethodError | Exception ignored) {
                    // fallback: attempt updateCourse with partial object
                    Course c = new Course(id, tableModel.getValueAt(r, 1).toString(),
                                           tableModel.getValueAt(r, 2).toString());
                    // set progress if model supports
                    try {
                        c.getClass().getMethod("setProgress", int.class).invoke(c, prog);
                    } catch (Exception ignore) {}
                    ok = dao.updateCourse(c);
                }

                if (ok) { JOptionPane.showMessageDialog(this, "Updated"); loadCourses(); }
                else JOptionPane.showMessageDialog(this, "Update failed");
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            }
        });

        btnDelete.addActionListener(e -> {
            int r = table.getSelectedRow();
            if (r < 0) { JOptionPane.showMessageDialog(this, "Select a course row first"); return; }
            int id = Integer.parseInt(tableModel.getValueAt(r, 0).toString());
            int yes = JOptionPane.showConfirmDialog(this, "Delete course id " + id + " ?","Confirm",JOptionPane.YES_NO_OPTION);
            if (yes != JOptionPane.YES_OPTION) return;
            try {
                CourseDAO dao = new CourseDAO();
                boolean ok = dao.deleteCourse(id);
                if (ok) { JOptionPane.showMessageDialog(this, "Deleted"); loadCourses(); }
                else JOptionPane.showMessageDialog(this, "Delete failed");
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            }
        });
    }

    private void loadCourses() {
        // clear
        tableModel.setRowCount(0);
        try {
            CourseDAO dao = new CourseDAO();
            List<Course> list = dao.getAllCourses();
            for (Course c : list) {
                // adapt to getters available in your Course model
                String name = safeGet(() -> c.getCourseName());
                String platform = safeGet(() -> {
                    try { return (String) c.getClass().getMethod("getPlatform").invoke(c); }
                    catch (Exception ex2) {
                        try { return (String) c.getClass().getMethod("getInstructor").invoke(c); }
                        catch (Exception ex3) { return ""; }
                    }
                });
                String prog = "0";
                try {
                    Object p = c.getClass().getMethod("getProgress").invoke(c);
                    prog = p != null ? String.valueOf(p) : "0";
                } catch (Exception ignore) {}

                tableModel.addRow(new Object[]{ safeGet(() -> c.getId()), name, platform, prog });
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Failed to load courses: " + e.getMessage());
        }
    }

    private <T> T safeGet(SupplierEx<T> s) {
        try { return s.get(); } catch (Exception e) { return null; }
    }

    // small functional interface to wrap reflective calls
    private interface SupplierEx<T> { T get() throws Exception; }

    // quick main to test this frame alone
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new CoursePanel().setVisible(true);
        });
    }
}
